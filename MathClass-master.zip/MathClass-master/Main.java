
//import java.io.File;
/*import javafx.application.Application;  
import javafx.scene.Group;  
import javafx.scene.media.Media;  
import javafx.scene.media.MediaPlayer;  
import javafx.scene.media.MediaView;  
import javafx.stage.Stage;  
*/public class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    Mathods a = new Mathods();
   // System.out.println(a.piNum(50));
   //System.out.println(a.eNum(45));
    //System.out.println(a.fib(5));
  //  System.out.println(a.floorPrice(9,2));
  a.cardValidator("Mastercard", 5217);
  }
}